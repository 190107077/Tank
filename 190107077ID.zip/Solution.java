/* 
Enter your code here. 
Create all the necessary classes and methods as per the requirements. 
*/
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import javafx.scene.input.KeyCode;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.Pane;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Circle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.util.Duration;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;






class Position{

private int x;
private int y;

public Position(int x, int y) {
    this.x = x;
    this.y = y;
}

// accessor methods
public void setX(int x) {
    this.x = x;
}

public void setY(int y) {
    this.y = y;
}

//mutator methods
public int getX() {
    return x;
}

public int getY() {
    return y;
}

public boolean equals (Position p) {    
    if(p.getX() == x && p.getY() == y) {
        return true;
    } else {
        return false;
    }
}
public String toString() {
    return "(" + x + "," + y + ")";
    }
}

interface Player {
    
   
    public void setMap(Map m);  // to add a map to Player
    
    public void moveRight();
    
    public void moveLeft();
    
    public void moveUp();
    
    public void moveDown();
    
    public void setPosition(Position p);  // to set position
    
    public Position getPosition(); // to get the position of player

    public double getAngle();

}

class MyPlayer implements Player {
    
    protected Position tankPosition;
    protected Map m;
    protected Rectangle player;
    protected Bullet bullet;

    
    /*
    0.0  0.1  0.2
    1.0  1.1  1.2
    2.0  2.1  2.2
    
     
    */
        
    @Override
    public void setMap(Map m) {
        this.m = m;
    }
    
     @Override
    public void moveRight() {
        int x = tankPosition.getX();
        int y = tankPosition.getY();
        int size = m.getSize();

        player.setRotate(90);
        if ((x + 1) < size && m.getValueAt(y,x+1) != 'B' && m.getValueAt(y,x+1) != 'S' && m.getValueAt(y,x+1) != 'W') {
            m.getChildren().remove(player);
            tankPosition.setX(x + 1);
            player.setX((x + 1) * 55);
            m.getChildren().add(player);
            System.out.println("Right");
            player.setVisible(true);
            if(m.getValueAt(y, x+1) == 'T'){
                player.setVisible(false);
            }
        } else {
            System.out.println("Invalid position");
        }
    }

    @Override
    public void moveLeft() {
        int x = tankPosition.getX();
        int y = tankPosition.getY();

        player.setRotate(270);
        if ((x - 1) >= 0 && m.getValueAt(y, x-1) != 'B' && m.getValueAt(y, x-1) != 'S' && m.getValueAt(y, x-1) != 'W') {
            m.getChildren().remove(player);
            tankPosition.setX(x - 1);
            player.setX((x-1) * 55);
            m.getChildren().add(player);
            System.out.println("Left");
            player.setVisible(true);
            if(m.getValueAt(y, x-1) == 'T'){
                player.setVisible(false);
            }
        } else {
            System.out.println("Invalid position");
        }

    }

    @Override
    public void moveUp() {
        int x = tankPosition.getX();
        int y = tankPosition.getY();

        player.setRotate(0);
        if ((y - 1) >= 0 && m.getValueAt(y-1,x) != 'B' && m.getValueAt(y-1,x) != 'S' && m.getValueAt(y-1,x) != 'W') {
            m.getChildren().remove(player);
            tankPosition.setY(y - 1);
            player.setY((y - 1) * 55);
            m.getChildren().add(player);
            System.out.println("Up");
            player.setVisible(true);
            if(m.getValueAt(y-1, x) == 'T'){
                player.setVisible(false);
            }
        } else {
            System.out.println("Invalid position");
        }
    }

    @Override
    public void moveDown() {
        int x = tankPosition.getX();
        int y = tankPosition.getY();
        int size = m.getSize();

        player.setRotate(180);
        if ((y + 1) < size && m.getValueAt(y+1,x) != 'B' && m.getValueAt(y+1,x) != 'S' && m.getValueAt(y+1,x) != 'W') {
            m.getChildren().remove(player);
            tankPosition.setY(y + 1);
            player.setY((y + 1) * 55);
            m.getChildren().add(player);
            System.out.println("Down");
            player.setVisible(true);
            if(m.getValueAt(y+1, x) == 'T'){
                player.setVisible(false);
            }
        } 
        else {
            System.out.println("Invalid position");
        }
    }
    
    @Override
    public void setPosition(Position tankPosition) {
        this.tankPosition = tankPosition;
    }
    
    @Override
    public Position getPosition() {
        return tankPosition;
    }

    @Override
    public double getAngle(){
        return player.getRotate();
    }

}


class Map extends Pane{
    
    private File file;
    private int size;
    private char map[][];
    private Position start;
    private char check;
    private int GRID = 55;

    Image steel = new Image("resources\\steel.png");
    Image brick = new Image("resources\\brick.png");
    Image water = new Image("resources\\water.png");
    Image trees = new Image("resources\\tree.png");
    
    public Map(File file) throws Exception{
        
        Scanner scan = new Scanner(file);
        size = Integer.parseInt(scan.nextLine());
        
        map = new char[size][size];
        
        for(int i = 0; i < size; i++) {
            for(int j = 0; j < size; j++){
                map[j][i] = scan.next().charAt(0); 
                if(map[j][i] == 'R' || map[j][i] == 'L' || map[j][i] == 'D' || map[j][i] == 'U') {
                    throw new InvalidMapException("Not enough map elements");
                }
                if(map[j][i] == 'P') {
                    start = new Position(j, i);
                    check = map[j][i];
                }

            }
        }
        
        if(check != 'P'){
            throw new InvalidMapException("Map size can not be zero");
        }

        

        for(int x = 0; x < size; x++) {
            for(int y = 0; y < size; y++) {
                Rectangle grid = new Rectangle(x * GRID, y * GRID, GRID, GRID);
                if(map[x][y] == '0' || map[x][y] == 'P') {
                    grid.setFill(Color.BLACK);
                }
                else if(map[x][y] == 'S') {
                    ImagePattern radialGradient = new ImagePattern(steel, Character.getNumericValue(x) * GRID, Character.getNumericValue(y) * GRID, GRID, GRID, false);
                    grid.setFill(radialGradient);
                }

                else if(map[x][y] == 'B') {
                    ImagePattern radialGradient = new ImagePattern(brick, Character.getNumericValue(x) * GRID, Character.getNumericValue(y) * GRID, GRID, GRID, false);
                    grid.setFill(radialGradient);
                }

                else if(map[x][y] == 'W') {
                    ImagePattern radialGradient = new ImagePattern(water, Character.getNumericValue(x) * GRID, Character.getNumericValue(y) * GRID, GRID, GRID, false);
                    grid.setFill(radialGradient);
                }

                else if(map[x][y] == 'T') {
                    ImagePattern radialGradient = new ImagePattern(trees, Character.getNumericValue(x) * GRID, Character.getNumericValue(y) * GRID, GRID, GRID, false);
                    grid.setFill(radialGradient);
                }

                grid.setStroke(Color.GREY);
                getChildren().add(grid);
            }
        }
    }
    
    public int getSize() {
        return size;
    }
    
    public char getValueAt(int row, int column) {
        return map[column][row];
    }
    
    public void print () throws InvalidMapException {
        if(size == 0) {
            throw new InvalidMapException("Map size can not be zero");
        }
        else {
            for(int i = 0; i < size; i++) {
                for(int j = 0; j < size; j++) {
                    System.out.print(map[j][i] + " ");
                    if(j==size-1){
                        System.out.println();
                    }
                }
            }
        }
    } 
    
    public Position getStartPosition(){
        return start;
    } 
}

class Game{
    
    private Map m;
    private ArrayList<Player> players;
    private Position start;
    private Player p;
    
    public Game(Map m) {
        this.m = m;
        players = new ArrayList<>();
        start = m.getStartPosition();
    }
    
    public void setMap(Map m) {
        this.m = m;
    }
    
    public void addPlayer(Player p) {
        this.p = p;
        p.setPosition(start);
        p.setMap(m);
        players.add(p);
    }
}

class InvalidMapException extends Exception {
    
    public InvalidMapException(String message) {
        super(message);
    }
}

class Tank extends MyPlayer {

   
    public Tank(Map map) {
        Image tank = new Image("resources\\tank.png");
        this.m = map;
        tankPosition = map.getStartPosition();
        ImagePattern radialGradient = new ImagePattern(tank, tankPosition.getX() * 55, tankPosition.getX() * 55, 55, 55, false);
        player = new Rectangle(tankPosition.getX() * 55,tankPosition.getY() * 55, 55, 55);
        player.setFill(radialGradient);
        player.setStroke(Color.BLACK);
        m.getChildren().add(player);
    }
 
}

class Bullet {
    private Map m;
    private Circle bullet;
    private Position tempPosition; 
    private Position position; 
    private Timeline animation;
    private int col;
    private int row;
    private Player player;

    public Bullet(Map m, Player player) {
        this.m = m;
        tempPosition = player.getPosition();
        position = tempPosition;

        int x = position.getX();
        int y = position.getY();

        row = x * 55 + 55/2;
        col = y * 55 + 55/2;

        bullet = new Circle(position.getX() * 55 +55 / 2,position.getY() * 55 + 55 / 2,5, Color.YELLOW);
        m.getChildren().add(bullet);


        //Up
        if(player.getAngle() == 0.0){
          animation = new Timeline(
          new KeyFrame(Duration.millis(5), e -> {
            if(col-1 > 0 && m.getValueAt(col/55, row/55) != 'B' && m.getValueAt(col/55, row/55) != 'S'){
                col -= 1;
                bullet.setCenterY(col);
            } else {
                animation.stop();
            }
            
          }));
          animation.setCycleCount(Timeline.INDEFINITE);
          animation.play();// 

        }

        //Right
        if(player.getAngle() == 90.0){
            animation = new Timeline(
            new KeyFrame(Duration.millis(5), e -> {
                if(row + 1 < m.getSize() * 55 && m.getValueAt(col/55, row/55) != 'B' && m.getValueAt(col/55, row/55) != 'S'){
                    row += 1;
                    bullet.setCenterX(row);
                } else {
                    animation.stop();
                }
            }));
            animation.setCycleCount(Timeline.INDEFINITE);
            animation.play(); //  
        }

        //Down
        if(player.getAngle() == 180.0){
            animation = new Timeline(
            new KeyFrame(Duration.millis(5), e -> {
                if(col + 1 < m.getSize() * 55 && m.getValueAt(col/55, row/55) != 'B' && m.getValueAt(col/55, row/55) != 'S') {
                    col += 1;
                    bullet.setCenterY(col);  
                } else {
                    animation.stop();
                }
            }));
            animation.setCycleCount(Timeline.INDEFINITE);
            animation.play(); //  
        }

        //Left
        if(player.getAngle() == 270.0){
            animation = new Timeline(
            new KeyFrame(Duration.millis(5), e -> {
                if(row - 1 > 0 && m.getValueAt(col/55, row/55) != 'B' && m.getValueAt(col/55, row/55) != 'S') {
                    row -= 1;
                    bullet.setCenterX(row);
                } else {
                    animation.stop();
                }
            }));
            animation.setCycleCount(Timeline.INDEFINITE);
            animation.play(); //  
        }

        if(col == 55*m.getSize()){
            animation.stop();
        }

        System.out.println(position.getX() + " " + position.getY());
    }

    public void stop(){
        animation.stop();
    }

    public Position getPosition() {
        return position;
    }
} 

class BotPlayer extends MyPlayer {

    protected Position botPosition;


    public BotPlayer(Map map){
        Random random = new Random();
        int x = 0;
        int y = 0;
        //to check x and y are not equal to brick, steel,tree, water
        boolean check = false;
        while(check == false){
            int a = random.nextInt(map.getSize()-1);
            int b = random.nextInt(map.getSize()-1);
            x = a;
            y = b;
            if(map.getValueAt(y,x) != 'B' && map.getValueAt(y,x) != 'S' && map.getValueAt(y,x) != 'T' && map.getValueAt(y,x) != 'W'){
                check = true;  
            }
        }

        //System.out.println(x + " " + y);

        Image bot = new Image("resources\\bot.jfif");
        this.m = map;
        ImagePattern radialGradient = new ImagePattern(bot, x * 55, y * 55, 55, 55, false);
        player = new Rectangle(x * 55,y * 55, 55, 55);
        botPosition = new Position(x,y);
        player.setFill(radialGradient);
        player.setStroke(Color.BLACK);
        m.getChildren().add(player);

        // tankPosition.setX(x);
        // tankPosition.setY(y);

        System.out.println(botPosition.getX() + " " + botPosition.getY());
    }
}

    class HBotPlayer extends MyPlayer{

        private int col;
        private int row;
        private Position botPosition;
        private Timeline animation;
        private int x = 0;
        private int y = 0;
        private boolean right = false;


        public HBotPlayer(Map map){
        Random random = new Random();
        
        
        this.m = map;

        //to check x and y are not equal to brick, steel,tree, water
        boolean check = false;
        while(check == false){
            int a = random.nextInt(map.getSize()-1);
            int b = random.nextInt(map.getSize()-1);
            x = a;
            y = b;
            if(map.getValueAt(y,x) != 'B' && map.getValueAt(y,x) != 'S' && map.getValueAt(y,x) != 'T' && map.getValueAt(y,x) != 'W'){
                check = true;  
            }
        }

        //System.out.println(x + " " + y);

        Image bot = new Image("resources\\bot.jfif");
        ImagePattern radialGradient = new ImagePattern(bot, x * 55, y * 55, 55, 55, false);
        player = new Rectangle(x * 55,y * 55, 55, 55);
        botPosition = new Position(x,y);
        player.setFill(radialGradient);
        player.setStroke(Color.BLACK);
        m.getChildren().add(player);
        System.out.println(x + " " + y);
        System.out.println(botPosition.getX() + " " + botPosition.getY());

        // tankPosition.setX(x);
        // tankPosition.setY(y);
        
        animation = new Timeline(
            new KeyFrame(Duration.millis(500),e -> {
                if(x  > 0 && m.getValueAt(y, x-1) != 'B' && m.getValueAt(y, x-1) != 'S' && m.getValueAt(y, x-1) != 'W' && right == false) {
                    x = x - 1;
                    botPosition.setX(x);
                    player.setX(x * 55);
                    player.setRotate(270);
                } else {
                    right = true;
                }if(x < map.getSize()-1 && m.getValueAt(y, x+1) != 'B' && m.getValueAt(y, x+1) != 'S' && m.getValueAt(y, x+1) != 'W' && right == true){
                    x = x + 1;
                    botPosition.setX(x);
                    player.setX(x * 55);
                    player.setRotate(90);
                } else {
                    right = false;
                }

            }));
        animation.setCycleCount(Timeline.INDEFINITE);
        animation.play();
        
    }
}

class VBotPlayer extends MyPlayer{

        private int col;
        private int row;
        private Position botPosition;
        private Timeline animation;
        private int x = 0;
        private int y = 0;
        private boolean right = false;


        public VBotPlayer(Map map){
        Random random = new Random();
        
        
        this.m = map;

        //to check x and y are not equal to brick, steel,tree, water
        boolean check = false;
        while(check == false){
            int a = random.nextInt(map.getSize()-1);
            int b = random.nextInt(map.getSize()-1);
            x = a;
            y = b;
            if(map.getValueAt(y,x) != 'B' && map.getValueAt(y,x) != 'S' && map.getValueAt(y,x) != 'T' && map.getValueAt(y,x) != 'W'){
                check = true;  
            }
        }

        //System.out.println(x + " " + y);

        Image bot = new Image("resources\\bot.jfif");
        ImagePattern radialGradient = new ImagePattern(bot, x * 55, y * 55, 55, 55, false);
        player = new Rectangle(x * 55,y * 55, 55, 55);
        botPosition = new Position(x,y);
        player.setFill(radialGradient);
        player.setStroke(Color.BLACK);
        m.getChildren().add(player);
        System.out.println(x + " " + y);
        System.out.println(botPosition.getX() + " " + botPosition.getY());

        // tankPosition.setX(x);
        // tankPosition.setY(y);
        
        animation = new Timeline(
            new KeyFrame(Duration.millis(500),e -> {
                if(y  > 0 && m.getValueAt(y-1, x) != 'B' && m.getValueAt(y-1, x) != 'S' && m.getValueAt(y-1, x) != 'W' && right == false) {
                    y = y - 1;
                    botPosition.setY(y);
                    player.setY(y * 55);
                    player.setRotate(0);
                } else {
                    right = true;
                }if(y < map.getSize()-1 && m.getValueAt(y+1, x) != 'B' && m.getValueAt(y+1, x) != 'S' && m.getValueAt(y+1, x) != 'W' && right == true){
                    y = y + 1;
                    botPosition.setY(y);
                    player.setY(y * 55);
                    player.setRotate(180);
                } else {
                    right = false;
                }

            }));
        animation.setCycleCount(Timeline.INDEFINITE);
        animation.play();
        
    }
}

public class Solution extends Application{

    private Timeline timer;
    private Bullet b;
    private HBotPlayer bot;
    private Position botPosition;
    private Position bulletPosition;
    private boolean exp = true;

    @Override
    public void start(Stage primaryStage) throws Exception{

        
        final Parameters params = getParameters();
        final List<String> parameters = params.getRaw();
        final String file = parameters.get(0);

        Map map = new Map(new File(file));
        Tank player = new Tank(map);

        

        EventHandler<ActionEvent> eventHandler = e -> {
            
                if(exp){
                  new HBotPlayer(map); 
                  exp = false; 
                } else {
                    new VBotPlayer(map);
                    exp = true;
                }
                
        };
            
        timer = new Timeline(
        new KeyFrame(Duration.millis(15000), eventHandler));
        timer.setCycleCount(Timeline.INDEFINITE);
        timer.play();

        Scene scene = new Scene(map, 55*map.getSize(), 55*map.getSize());

       

        scene.setOnKeyPressed(event -> {
            KeyCode keyCode =  event.getCode();
            if(keyCode.equals(KeyCode.UP)){
                player.moveUp();
            }
            if(keyCode.equals(KeyCode.DOWN)){
                player.moveDown();
            }
            if(keyCode.equals(KeyCode.LEFT)){
                player.moveLeft();
            }
            if(keyCode.equals(KeyCode.RIGHT)){
                player.moveRight();
            }
            if(keyCode.equals(KeyCode.SPACE)){
                b = new Bullet(map, player);
            }
        });
        

        primaryStage.setTitle("Game");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}





/*
Input and Output has been done for you.
Various conditions are meant to check individual classes separately.
You still need to implement completely all the necessary classes with their corresponding methods,
but the correctness for each class is checked individually.
In other words, you already get some partial points 
for implementing some classes completely and correctly, 
even if other classes are complete but still may not work properly.
*/

// public class Solution{

// 	public static void main(String[] args) {
//         Scanner input = new Scanner(System.in);
//         String className = input.nextLine();
        
//         // Checking the implementation of the Position class
//         if(className.equals("Position")){
//             Position p1 = new Position(input.nextInt(), input.nextInt());
//             System.out.println(p1);
//             p1.setX(5);
//             System.out.println(p1.getX());
            
//             Position p2 = new Position(5, 10);
//             System.out.println(p1.equals(p2));            
//         }
        
//         // Checking the implementation of the Map class
//         else if(className.equals("Map")){
//             try{
//                 Map map = new Map(input);
//                 map.print();
//                 int size = map.getSize();
//                 System.out.println(size);		
//                 System.out.println(map.getValueAt(size/2, size/2)); 
//             }
//             catch(Exception e){}
//         }
        
//         // Checking the Player interface and the MyPlayer class
//         else if(className.equals("Player")){
//             Player player = new MyPlayer();
//             System.out.println(Player.class.isInterface());  
//             System.out.println(player instanceof Player);
//             System.out.println(player instanceof MyPlayer);
//         }
        
//         // Checking the InvalidMapException class
//         else if(className.equals("Exception")){
//             try{
//                 throw new InvalidMapException("Some message");
//             }
//             catch(InvalidMapException e){
//                 System.out.println(e.getMessage());
//             }
//         }
        
//         // Checking the Game class and all of its components
//         else if(className.equals("Game")){
            
//             // Initialize player, map, and the game
//             Player player = new MyPlayer();
//             Game game = null;

//             try{
//                 game = new Game(new Map(input));
//             }
//             catch(InvalidMapException e){ // custom exception
//                 System.out.println(e.getMessage());
//                 System.exit(0);
//             }

//             game.addPlayer(player);

//             // Make the player move based on the commands given in the input
//             String moves = input.next();
//             char move;
//             for(int i=0; i<moves.length(); i++){
//                 move = moves.charAt(i);
//                 switch(move){
//                     case 'R':
//                         player.moveRight();
//                         break;
//                     case 'L':
//                         player.moveLeft();
//                         break;
//                     case 'U':
//                         player.moveUp();
//                         break;
//                     case 'D':
//                         player.moveDown();
//                         break;
//                 }
//             }

//             // Determine the final position of the player after completing all the moves above
//             Position playerPosition = player.getPosition();
//             System.out.println("Player final position");
//             System.out.println("Row: " + playerPosition.getY());
//             System.out.println("Col: " + playerPosition.getX());
//         }
// 	}
// }