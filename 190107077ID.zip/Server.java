import java.io.*;
import java.net.*;

import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import javafx.scene.input.KeyCode;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.Pane;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Circle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.util.Duration;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;

public class Server  extends Application{
	private Timeline timer;
    private Bullet b;
    private HBotPlayer bot;
    private Position botPosition;
    private Position bulletPosition;
    private boolean exp = true;

    @Override
    public void start(Stage primaryStage) throws Exception{

        
        final Parameters params = getParameters();
        final List<String> parameters = params.getRaw();
        final String file = parameters.get(0);

        Map map = new Map(new File(file));
        Game game = new Game(map);
       

        Scene scene = new Scene(map, 55*map.getSize(), 55*map.getSize());

       
        new Thread( () -> {
			try {
				// Create a server socket
				ServerSocket serverSocket = new ServerSocket(8000);


				while (true) {
					// Listen for a new connection request
					Socket socket = serverSocket.accept();
					
					// Create and start a new thread for the connection
					new Thread(new HandleAClient(socket)).start();
				}
			}
			catch(IOException ex) {
			System.out.println(ex);
			}
			}).start();
        

        primaryStage.setTitle("Game");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}

class HandleAClient implements Runnable {
	private Socket socket; // A connected socket
	/** Construct a thread */
	
	public HandleAClient(Socket socket) {
		this.socket = socket;
		}
		/** Run a thread */
		public void run() {
		
		try {
			// Create data input and output streams
			DataInputStream inputFromClient = new DataInputStream(socket.getInputStream());
			DataOutputStream outputToClient = new DataOutputStream(socket.getOutputStream());
			// Continuously serve the client
			while (true) {
			
			}
		}
		catch(IOException ex) {
			ex.printStackTrace();
		}
	}
}