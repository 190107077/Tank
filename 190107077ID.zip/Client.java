import java.io.*;
import java.net.*;

import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import javafx.scene.input.KeyCode;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.Pane;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Circle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.util.Duration;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;


public class Client extends Application {
	// IO streams
	DataOutputStream toServer = null;
	DataInputStream fromServer = null;
	Map map1;
	Map map2;
	Map map3;
	Tank player;
	Timeline timerAnimation;
	Timeline timerAnimation1;
	int time;
	int time1;
	Bullet b;
	Timeline timer;
	Timeline timer1;

	Scene scene1;
	Scene scene2;
	Scene scene3;
	
	boolean exp = true;
	boolean exp1 = true;
	@Override // Override the start method in the Application class
	public void start(Stage primaryStage) throws FileNotFoundException{

		

		File file3 = new File("resources\\map2.txt");
		File file2 = new File("resources\\map1.txt");
		File file1 = new File("resources\\map0.txt");
		
		try{
			map1 = new Map(file1);
			map2 = new Map(file2);
			map3 = new Map(file3);

			player = new Tank(map1);
			new VBotPlayer(map1);


		} catch(Exception e){
			System.out.println(e.getMessage());
		}

		scene1 = new Scene(map1, 55*map1.getSize(), 55*map1.getSize());
		scene2 = new Scene(map2, 55*map2.getSize(), 55*map2.getSize());
		scene3 = new Scene(map3, 55*map3.getSize(), 55*map3.getSize());
		
		EventHandler<ActionEvent> eventHandler = e -> {
            
                if(exp){
                  new HBotPlayer(map1); 
                  exp = false; 
                } else {
                    new VBotPlayer(map1);
                    exp = true;
                }
                
        };
        timer = new Timeline(
        new KeyFrame(Duration.millis(30000), eventHandler));
        timer.setCycleCount(Timeline.INDEFINITE);
        timer.play();


       	secondLevel(primaryStage);
       	thirdLevel(primaryStage);

		primaryStage.setTitle("Client"); // Set the stage title
		primaryStage.setScene(scene1); // Place the scene in the stage
		primaryStage.show(); // Display the stage

		scene1.setOnKeyPressed(event -> {
            KeyCode keyCode =  event.getCode();
            if(keyCode.equals(KeyCode.UP)){
                player.moveUp();
            }
            if(keyCode.equals(KeyCode.DOWN)){
                player.moveDown();
            }
            if(keyCode.equals(KeyCode.LEFT)){
                player.moveLeft();
            }
            if(keyCode.equals(KeyCode.RIGHT)){
                player.moveRight();
            }
            if(keyCode.equals(KeyCode.SPACE)){
                b = new Bullet(map1, player);
            }
        });
		
		scene2.setOnKeyPressed(event -> {
            KeyCode keyCode =  event.getCode();
            if(keyCode.equals(KeyCode.UP)){
                player.moveUp();
            }
            if(keyCode.equals(KeyCode.DOWN)){
                player.moveDown();
            }
            if(keyCode.equals(KeyCode.LEFT)){
                player.moveLeft();
            }
            if(keyCode.equals(KeyCode.RIGHT)){
                player.moveRight();
            }
            if(keyCode.equals(KeyCode.SPACE)){
                b = new Bullet(map2, player);
            }
        });

        scene3.setOnKeyPressed(event -> {
            KeyCode keyCode =  event.getCode();
            if(keyCode.equals(KeyCode.UP)){
                player.moveUp();
            }
            if(keyCode.equals(KeyCode.DOWN)){
                player.moveDown();
            }
            if(keyCode.equals(KeyCode.LEFT)){
                player.moveLeft();
            }
            if(keyCode.equals(KeyCode.RIGHT)){
                player.moveRight();
            }
            if(keyCode.equals(KeyCode.SPACE)){
                b = new Bullet(map3, player);
            }
        });
		
		try {
			// Create a socket to connect to the server
			Socket socket = new Socket("localhost", 8000);
			// Socket socket = new Socket("130.254.204.36", 8000);
			// Socket socket = new Socket("drake.Armstrong.edu", 8000);
			// Create an input stream to receive data from the server
			fromServer = new DataInputStream(socket.getInputStream());
			// Create an output stream to send data to the server
			toServer = new DataOutputStream(socket.getOutputStream());
			System.out.println(socket.isConnected());
		}
		catch (IOException ex) {
			System.out.println(ex.toString() + '\n');
		}
	}

	public void secondLevel(Stage primaryStage){

		time = 120;

		EventHandler<ActionEvent> eventHandler = e -> {
				
			time--;
				
			if(time == 0){
				timerAnimation.stop();
				primaryStage.setScene(scene2);
				player = new Tank(map2);
				new VBotPlayer(map2);
				EventHandler<ActionEvent> eventHandler1 = e1 -> {
            
                if(exp){
                  new HBotPlayer(map2); 
                  exp1 = false; 
                } else {
                    new VBotPlayer(map2);
                    exp1 = true;
                }
                
		        };
		        timer = new Timeline(
		        new KeyFrame(Duration.millis(30000), eventHandler1));
		        timer.setCycleCount(Timeline.INDEFINITE);
		        timer.play();
			}

		};
			
		timerAnimation = new Timeline(
		new KeyFrame(Duration.millis(750), eventHandler));
		timerAnimation.setCycleCount(Timeline.INDEFINITE);
		timerAnimation.play();


	}

	public void thirdLevel(Stage primaryStage) {
		time1 = 245;

		EventHandler<ActionEvent> eventHandler = e -> {
				
			time1--;
				
			if(time1 == 0){
				timerAnimation1.stop();
				primaryStage.setScene(scene3);
				player = new Tank(map3);
				new VBotPlayer(map3);
				EventHandler<ActionEvent> eventHandler1 = e1 -> {
            
                if(exp){
                  new HBotPlayer(map3); 
                  exp1 = false; 
                } else {
                    new VBotPlayer(map3);
                    exp1 = true;
                }
                
		        };
		        timer1 = new Timeline(
		        new KeyFrame(Duration.millis(30000), eventHandler1));
		        timer1.setCycleCount(Timeline.INDEFINITE);
		        timer1.play();
			}
                           
		};
			
		timerAnimation1 = new Timeline(
		new KeyFrame(Duration.millis(750), eventHandler));
		timerAnimation1.setCycleCount(Timeline.INDEFINITE);
		timerAnimation1.play(); 
	}
}